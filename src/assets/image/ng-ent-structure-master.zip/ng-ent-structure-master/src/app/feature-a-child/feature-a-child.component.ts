import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-feature-a-child',
  templateUrl: './feature-a-child.component.html',
  styleUrls: ['./feature-a-child.component.scss']
})
export class FeatureAChildComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

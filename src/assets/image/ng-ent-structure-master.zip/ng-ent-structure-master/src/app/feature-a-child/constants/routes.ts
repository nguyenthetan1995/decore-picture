import { Routes } from '@angular/router';
import { FeatureAChildComponent } from '../feature-a-child.component';

export const featureAChildRoutes: Routes = [
  {
    path: '',
    component: FeatureAChildComponent
  }
];

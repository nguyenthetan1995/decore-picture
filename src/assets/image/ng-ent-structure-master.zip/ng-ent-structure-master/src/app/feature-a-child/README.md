# FeatureAChild NgModule

This is child of FeatureA.

Apply same structure as `CoreModule` (some directory can be omit).

# FeatureA NgModule

Apply same structure as `CoreModule` (some directory can be omit).

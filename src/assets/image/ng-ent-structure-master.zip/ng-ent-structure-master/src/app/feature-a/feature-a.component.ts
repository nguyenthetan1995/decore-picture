import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-feature-a',
  templateUrl: './feature-a.component.html',
  styleUrls: ['./feature-a.component.scss']
})
export class FeatureAComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

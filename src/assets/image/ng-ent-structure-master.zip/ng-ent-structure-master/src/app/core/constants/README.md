# Constants directory

This directory tends to be a place to place all constants of the NgModule.

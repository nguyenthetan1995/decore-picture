# Directives directory

This directory tends to be a place to place Directives belong to the NgModule.

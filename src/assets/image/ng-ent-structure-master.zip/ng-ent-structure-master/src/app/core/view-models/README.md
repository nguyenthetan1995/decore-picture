# View-Models directory

This directory tends to be a place to place View Models.

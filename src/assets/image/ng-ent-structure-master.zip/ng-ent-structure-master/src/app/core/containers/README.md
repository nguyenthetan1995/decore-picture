# Containers directory
This directory tends to be a place to place **Smart Components**.

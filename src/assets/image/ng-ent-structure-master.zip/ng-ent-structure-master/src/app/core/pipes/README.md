# Pipes directory

This directory tends to be a place to place your custom Angular Pipes.

# Data-Services directory

This directory tends to be a place to place DataService (e.g: calling HTTP, WebSocket,...).

# Models directory

This directory tends to be a place to place Business Models.

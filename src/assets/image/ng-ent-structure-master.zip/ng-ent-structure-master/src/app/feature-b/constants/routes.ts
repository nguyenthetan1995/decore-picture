import { Routes } from '@angular/router';
import { FeatureBComponent } from '../feature-b.component';

export const featureBRoutes: Routes = [
  {
    path: '',
    component: FeatureBComponent
  }
];

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-feature-b',
  templateUrl: './feature-b.component.html',
  styleUrls: ['./feature-b.component.scss']
})
export class FeatureBComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
